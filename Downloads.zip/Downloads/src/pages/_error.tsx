export default function Error() {
  return <div>An error as occured</div>;
}
