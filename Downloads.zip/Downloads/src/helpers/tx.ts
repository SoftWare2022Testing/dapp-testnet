import * as encoding from "@walletconnect/encoding";
import {ethers, BigNumber, utils } from "ethers";
import { apiGetAccountNonce, apiGetGasPrice } from "./api";

export async function getGasPrice(chainId: string): Promise<string> {
  const gasPrice = await apiGetGasPrice(chainId);
  return gasPrice;
}

export async function formatTestTransaction(account: string) {
  const [namespace, reference, address] = account.split(":");
  const chainId = `${namespace}:${reference}`;
  // nonce
  const _nonce = await apiGetAccountNonce(address, chainId);

  const nonce = encoding.sanitizeHex(encoding.numberToHex(_nonce));

  // gasPrice
  const _gasPrice = await getGasPrice(chainId);
  const gasPrice = encoding.sanitizeHex(_gasPrice);

  // gasLimit
  const _gasLimit = 21000;
  const gasLimit = encoding.sanitizeHex(encoding.numberToHex(_gasLimit));

  // value
  const _value = 0;
  const value = encoding.sanitizeHex(encoding.numberToHex(_value));

  const tx = { from: address, to: address, data: "0x", nonce, gasPrice, gasLimit, value };

  return tx;
}

export async function formatSendEtherTransaction(account: string) {
  const [namespace, reference, address] = account.split(":");
  const chainId = `${namespace}:${reference}`;
  const recipientAddress = "0xF88Def2456ac2D0Ad04231D06447b25fBF07e127";

  // nonce
  const _nonce = await apiGetAccountNonce(address, chainId);
  const nonce_ = encoding.sanitizeHex(encoding.numberToHex(_nonce));

  // gasPrice
  const _gasPrice = await getGasPrice(chainId);
  const gas_Price = encoding.sanitizeHex(_gasPrice);

  // gasLimit
  const _gasLimit = 21000;
  const gas_Limit = encoding.sanitizeHex(encoding.numberToHex(_gasLimit));

  // value
  // const amount = 0.05;
  // const _value = encoding.sanitizeHex(encoding.numberToHex(amount));
  const _value = ethers.utils.parseEther("0.0005").toHexString();

  const tx = { from: address, to: recipientAddress, gasPrice: gas_Price, gasLimit: gas_Limit, nonce: nonce_, value: _value};

  return tx;
}

